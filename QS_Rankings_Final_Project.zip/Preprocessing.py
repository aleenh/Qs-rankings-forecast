import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import random
import seaborn as sns
from sklearn.linear_model import LinearRegression
import matplotlib.patches as mpatches
import geopandas as gpd

# Step 1: Load the dataset
df = pd.read_csv("qs-world-rankings-2025.csv",
    encoding='utf-8-sig')

# Step 2: Initial inspection of the dataset
print("Initial Dataset Preview: ")
print(df.head())
print("\nDataset Info: ")
print(df.info())
print("\nDescriptive Statistics:")
print(df.describe())
print("\nColumns in the Dataset: ")
print(df.columns.tolist())
print("\nData Types: ")
print(df.dtypes)
print("\nMissing Values per Column: ")
print(df.isnull().sum())
print("\nUnique Values per Column: ")
print(df.nunique())

# Step 3: Drop duplicates and clean column names
df.drop_duplicates(inplace=True)
# Standardize column names (lowercase, underscores)
df.columns = df.columns.str.replace(' ', '_').str.lower().str.strip()

# Step 4: Drop 'location' column, keep 'location_full'
if 'location' in df.columns:
    df.drop(columns=['location'], inplace=True)

# Step 5: Assign unique ranks for ranges
def assign_unique_ranks_integer_safe(df, column):
    updated_ranks = [None] * len(df)
    range_groups = {}
    used_ranks = set()
    random_1401_plus_pool = list(range(1401, 1501))
    random.shuffle(random_1401_plus_pool)

    for i, val in df[column].items():
        if isinstance(val, str) and '-' in val:
            if val not in range_groups:
                range_groups[val] = []
            range_groups[val].append(i)

    for rank_range, indices in range_groups.items():
        start, end = map(int, rank_range.split('-'))
        step = end - start + 1
        ranks = list(range(start, start + len(indices)))
        for idx, rank in zip(indices, ranks):
            updated_ranks[idx] = rank
            used_ranks.add(rank)

    for i, val in df[column].items():
        if updated_ranks[i] is not None:
            continue
        if pd.isna(val):
            updated_ranks[i] = pd.NA
        elif not isinstance(val, str):
            rank = int(val)
            while rank in used_ranks:
                rank += 1
            updated_ranks[i] = rank
            used_ranks.add(rank)
        elif val.endswith('+'):
            if random_1401_plus_pool:
                rank = random_1401_plus_pool.pop()
            else:
                rank = 1501
                while rank in used_ranks:
                    rank += 1
            updated_ranks[i] = rank
            used_ranks.add(rank)
        elif val.isdigit():
            rank = int(val)
            while rank in used_ranks:
                rank += 1
            updated_ranks[i] = rank
            used_ranks.add(rank)

    return pd.Series(updated_ranks, dtype="Int64")

# Reset index to avoid index errors
df = df.reset_index(drop=True)

# Apply the function to fix ranks
df['2024_rank'] = assign_unique_ranks_integer_safe(df, '2024_rank')
df['2025_rank'] = assign_unique_ranks_integer_safe(df, '2025_rank')

# Step 6: Convert to numeric
numeric_columns = ['2024_rank', '2025_rank', 'qs_overall_score']
for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors='coerce')

#check for missing values
print(df.isnull().sum())

# Print original shape
print(f"Original shape: {df.shape}")
# List of columns you want to enforce complete data for (exclude 'qs_overall_score')
columns_to_check = [
    '2024_rank', 'international_faculty', 'international_students',
    'international_research_network', 'sustainability'
]

# Drop rows with missing values in these columns only
df_cleaned = df.dropna(subset=columns_to_check)
print(df_cleaned.isnull().sum())

# Print info
print(f"Original shape: {df.shape}")
print(f"New shape after dropping missing (excluding qs_overall_score): {df_cleaned.shape}")
print(f"Rows dropped: {df.shape[0] - df_cleaned.shape[0]}")


# Step 12: Plot Top 20 Countries with Most Universities

print("\n Top 20 Countries with Most Universities:\n")
print(df_cleaned['location_full'].value_counts().head(20))

df_cleaned['location_full'].value_counts().head(20).plot(kind='bar', figsize=(12, 6), color='skyblue')
plt.title('Top 20 Countries by Number of Universities')
plt.xlabel('Country')
plt.ylabel('Number of Universities')
plt.xticks(rotation=45)
plt.grid(axis='y')
plt.tight_layout()
plt.show()

# Top 10 by employment outcome
top_employment_universities = df_cleaned[["institution_name", "employment_outcomes"]].nlargest(10, "employment_outcomes")
print(top_employment_universities.to_string(index=False))

# Top 10 by academic reputation
best_academic_reputation = df_cleaned[["institution_name", "academic_reputation"]].nlargest(10, "academic_reputation")
print(best_academic_reputation.to_string(index=False))

# Top 10 by sustainability
best_sustainability_universities = df_cleaned[["institution_name", "sustainability"]].nlargest(10, "sustainability")
print(best_sustainability_universities.to_string(index=False))

# ✅ Group by location_full (only using cleaned data)
print("\nAverage Academic Reputation by Country:")
print(df_cleaned.groupby('location_full')['academic_reputation'].mean().sort_values(ascending=False))

print("\nAverage Employment Outcomes by Country:")
print(df_cleaned.groupby('location_full')['employment_outcomes'].mean().sort_values(ascending=False))

print("\nAverage Employer Reputation by Country:")
print(df_cleaned.groupby('location_full')['employer_reputation'].mean().sort_values(ascending=False))

# Step 8: Display ranks
print("\nFirst few rows of 2024-2025 Ranks: ")
print(df_cleaned[['2024_rank', '2025_rank']].head())

# Step 9: Rank improvement
df_cleaned = df.dropna(subset=columns_to_check).copy()
df_cleaned['rank_improvement'] = df_cleaned['2024_rank'] - df_cleaned['2025_rank']

print("Total universities in df_cleaned:", len(df_cleaned))


# Distribution Plot for 2025 Rank

plt.figure(figsize=(10, 6))
sns.histplot(df['2025_rank'], kde=True, bins=25)
plt.title("Distribution of 2025 Rank")
plt.xlabel("2025 Rank")
plt.ylabel("Count")
plt.grid(True)
plt.gca().invert_xaxis()
plt.show()

# Distribution Plot for 2025 Rank (from cleaned data)
plt.figure(figsize=(10, 6))
sns.histplot(df_cleaned['2025_rank'], kde=True, bins=25)
plt.title("Distribution of 2025 Rank")
plt.xlabel("2025 Rank")
plt.ylabel("Count")
plt.grid(True)
plt.gca().invert_xaxis()
plt.show()

# Step 11: Null check on cleaned data
print("\nMissing Values after preprocessing:")
print(df_cleaned.isnull().sum())

# Step 12: Save cleaned data
df_cleaned['2024_rank'] = df_cleaned['2024_rank'].astype(int)
df_cleaned['2025_rank'] = df_cleaned['2025_rank'].astype(int)

print("Rows with any remaining missing values:", df_cleaned.isnull().any(axis=1).sum())

df_cleaned.to_csv("cleanedData.csv",
    index=False,
    encoding='utf-8-sig')


# Step 11: Plot University Size Distribution
print("\nUniversity Size Distribution:\n")
print(df_cleaned['size'].value_counts().head(10))

plt.figure(figsize=(8,6))
ax = sns.countplot(x='size', data=df_cleaned, order=['S', 'M', 'L', 'XL'])
plt.title('Distribution of University Sizes')
plt.xlabel('University Size')
plt.ylabel('Number of Universities')
plt.grid(True, axis='y')

# Add value labels on each bar
for p in ax.patches:
    height = p.get_height()
    ax.annotate(f'{int(height)}',            # write the number (as integer, no .0)
                (p.get_x() + p.get_width() / 2., height), 
                ha='center', va='bottom', 
                fontsize=9, color='black', xytext=(0, 5),
                textcoords='offset points')

plt.tight_layout()
plt.show()

#Outlier detection
# Columns where outliers matter (scores, ratios — not ranks!)
outlier_columns = [
    'academic_reputation', 'employer_reputation', 'faculty_student',
    'citations_per_faculty', 'international_faculty', 'international_students',
    'international_research_network', 'employment_outcomes', 'sustainability'
]
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(16, 10))
for i, col in enumerate(outlier_columns, 1):
    plt.subplot(3, 3, i)
    sns.boxplot(data=df_cleaned, y=col, color='skyblue')
    plt.title(col.replace('_', ' ').title())
    plt.tight_layout()
plt.suptitle("Boxplots for Outlier Detection", fontsize=16, y=1.02)
plt.show()

# Step 3: Detect outliers using IQR method
print("Outlier Counts per Column (Using IQR Method):\n")

for col in outlier_columns:
    Q1 = df_cleaned[col].quantile(0.25)
    Q3 = df_cleaned[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    outliers = df_cleaned[(df_cleaned[col] < lower) | (df_cleaned[col] > upper)]
    print(f"{col}: {len(outliers)} outliers")

#Histogram 


# Input series
ranks = df_cleaned['2025_rank']

# Mean and median
mean_rank = ranks.mean()
median_rank = ranks.median()

# Define rank groups
def get_rank_group(rank):
    if rank <= 100:
        return 'Top 100'
    elif rank <= 500:
        return 'Top 500'
    else:
        return 'Others'

df_cleaned['rank_group'] = df_cleaned['2025_rank'].apply(get_rank_group)

# Plot histogram
plt.figure(figsize=(10, 7))
bin_edges = np.histogram_bin_edges(ranks, bins=30)
counts, bins, patches = plt.hist(ranks, bins=bin_edges, edgecolor='black')

# Apply colors per bin
for patch, left_bin in zip(patches, bins[:-1]):
    if left_bin <= 100:
        patch.set_facecolor('gold')
    elif left_bin <= 500:
        patch.set_facecolor('skyblue')
    else:
        patch.set_facecolor('lightgray')

# Add shaded areas
plt.axvspan(0, mean_rank, color='lightgreen', alpha=0.2, label='Above Average Rank')
plt.axvspan(median_rank, ranks.max(), color='salmon', alpha=0.2, label='Below Median Rank')

# Mean and median lines
plt.axvline(mean_rank, color='blue', linestyle='--', linewidth=2, label=f'Mean: {mean_rank:.2f}')
plt.axvline(median_rank, color='green', linestyle=':', linewidth=2, label=f'Median: {median_rank:.2f}')

# Invert axis
plt.gca().invert_xaxis()

# Titles and labels
plt.title("2025 Rank Distribution with Shaded Mean and Median Areas", fontsize=14)
plt.xlabel("2025 Rank (Better on the Right)", fontsize=12)
plt.ylabel("Number of Universities", fontsize=12)

#  legend
plt.legend(title="Rank Group", fontsize=10, title_fontsize=11)
plt.grid(True, axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# Step 15: Top 10 Universities by 2025 Rank
top10_2025_rank = df_cleaned.sort_values(by='2025_rank', ascending=True).head(10)
print("\nTop 10 Universities by 2025 Rank:")
print(top10_2025_rank[['institution_name', '2025_rank']])

# Barplot of Top 10 Universities by 2025 Rank
plt.figure(figsize=(10, 6))
sns.barplot(x='2025_rank', y='institution_name', data=top10_2025_rank, palette="mako")
plt.title('Top 10 Universities by 2025 Rank')
plt.xlabel('2025 Rank')
plt.ylabel('Institution')
plt.grid(True, axis='x')
plt.tight_layout()
plt.show()


# 1. Load World Map
world = gpd.read_file(r"C:\Users\User\Downloads\ne_110m_admin_0_countries\ne_110m_admin_0_countries.shp")

# 2. Get Top 10 Universities by 2025 Rank
top10_universities = df_cleaned.sort_values(by='2025_rank').head(10).copy()

# 3. Add coordinates manually (based on your actual top 10)
# Make sure these match the universities in the sorted list
top10_universities['latitude'] = [42.3601, 51.4988, 51.7548, 42.3736, 52.2043,
                                  37.4275, 47.3769, 1.2966, 51.5246, 34.1377]

top10_universities['longitude'] = [-71.0942, -0.1749, -1.2544, -71.1097, 0.1149,
                                   -122.1697, 8.5417, 103.7764, -0.1339, -118.1253]

# Assign continents (for coloring)
top10_universities['continent'] = [
    'North America', 'Europe', 'Europe', 'North America', 'Europe',
    'North America', 'Europe', 'Asia', 'Europe', 'North America'
]

# Color mapping
continent_colors = {'North America': 'lightblue', 'Europe': 'lightpink', 'Asia': 'lightgreen'}
top10_universities['color'] = top10_universities['continent'].map(continent_colors)

# 4. Plot the world and universities
fig, ax = plt.subplots(figsize=(16, 10))

# Base map
world.plot(ax=ax, color='whitesmoke', edgecolor='gray')

# Fill selected continents
world[world['NAME'].isin(['United States', 'Canada', 'Mexico'])].plot(ax=ax, color='lightblue', edgecolor='gray')
world[world['NAME'].isin(['United Kingdom', 'Switzerland', 'Germany', 'France', 'Italy', 'Spain',
                          'Netherlands', 'Belgium', 'Austria', 'Ireland', 'Denmark', 'Norway', 'Sweden'])]\
    .plot(ax=ax, color='lightpink', edgecolor='gray')
world[world['NAME'].isin(['Singapore', 'China', 'Japan', 'India', 'South Korea', 'Malaysia'])]\
    .plot(ax=ax, color='lightgreen', edgecolor='gray')

# Plot university points
for _, row in top10_universities.iterrows():
    plt.scatter(row['longitude'], row['latitude'], color=row['color'], s=100, edgecolor='black')

# Annotate with university names
for idx, row in top10_universities.iterrows():
    x_offset = 10 if row['continent'] == 'North America' else 5
    y_offset = 5 if idx % 2 == 0 else -5

    plt.annotate(
        row['institution_name'],
        xy=(row['longitude'], row['latitude']),
        xytext=(row['longitude'] + x_offset, row['latitude'] + y_offset),
        fontsize=10,  # Increase font size
        color='black',
        ha='left',
        bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="black", lw=0.5),  # Add white box behind text
        arrowprops=dict(arrowstyle="->", color='black', lw=1)
    )

# Custom legend
legend_handles = [
    mpatches.Patch(color='lightblue', label='North America'),
    mpatches.Patch(color='lightpink', label='Europe'),
    mpatches.Patch(color='lightgreen', label='Asia')
]
plt.legend(handles=legend_handles, title="Continent")

# Final touches
plt.xlim(-130, 130)
plt.ylim(-10, 65)
plt.title('Top 10 Universities by 2025 Rank - World Map', fontsize=14)
plt.grid(True)
plt.tight_layout()
plt.show()





# Step 13: Correlation Plot
corr_rank = df.corr(numeric_only=True)['2025_rank'].drop('2025_rank').sort_values()
corr_rank.plot(kind='barh', color='skyblue', figsize=(9, 6))
plt.title('Correlation with 2025 Rank')
plt.xlabel('Correlation')
plt.grid(True)
plt.tight_layout()
plt.show()

print("Correlation between 2025 rank and the features: ")
print(df.corr(numeric_only=True)['2025_rank'].sort_values())

# # Step 14: Regression Plots

import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np
import seaborn as sns

features_to_plot = [
    'academic_reputation', 'international_research_network', 'sustainability',
    'employer_reputation', 'citations_per_faculty', 'employment_outcomes',
    'international_faculty', 'international_students'
]

n_features = len(features_to_plot)
n_cols = 3
n_rows = (n_features + n_cols - 1) // n_cols

fig, axes = plt.subplots(n_rows, n_cols, figsize=(18, n_rows * 4))
axes = axes.flatten()

# Global rank range based on the full cleaned DataFrame
max_rank = df_cleaned['2025_rank'].max()

for i, feature in enumerate(features_to_plot):
    df_feat = df_cleaned[[feature, '2025_rank']].dropna()
    X = df_feat[[feature]]
    y = df_feat['2025_rank']

    model = LinearRegression()
    model.fit(X, y)
    r2 = model.score(X, y)
    y_pred = model.predict(X)

    sns.regplot(data=df_feat, x=feature, y='2025_rank',
                ax=axes[i],
                scatter_kws={'alpha': 0.6, 's': 20},
                line_kws={'color': 'red'})

    axes[i].set_title(f"{feature.replace('_', ' ').title()}", fontsize=13)
    axes[i].set_xlabel(feature.replace('_', ' ').title())
    axes[i].set_ylabel("2025 Rank")
    axes[i].grid(True)
    
    # Y-axis: force full rank range
    axes[i].set_ylim(max_rank + 50, 1)

    # R² annotation
    axes[i].text(0.05, 0.9, f"$R^2$ = {r2:.2f}", transform=axes[i].transAxes,
                 fontsize=12, color='black', fontweight='bold',
                 bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))

# Remove unused axes
for j in range(i + 1, len(axes)):
    fig.delaxes(axes[j])

fig.suptitle("Feature Correlation with 2025 Rank\n(Scatter + Regression + $R^2$)", fontsize=16)
plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.show()


# features_to_plot = [
#     'academic_reputation', 'international_research_network', 'sustainability',
#     'employer_reputation', 'citations_per_faculty', 'employment_outcomes',
#     'international_faculty', 'international_students'
# ]

# for feature in features_to_plot:
#     df_clean = df[[feature, '2025_rank']].dropna()
#     X_single_feature = df_clean[[feature]]
#     y = df_clean['2025_rank']

#     model = LinearRegression()
#     model.fit(X_single_feature, y)
#     r2 = model.score(X_single_feature, y)

#     min_rank = df_clean['2025_rank'].min()
#     max_rank = df_clean['2025_rank'].max()
#     ticks = [1] + list(np.arange(200, max_rank + 100, 200))

#     plt.figure(figsize=(8, 5))
#     sns.regplot(data=df_clean, x=feature, y='2025_rank',
#                 scatter_kws={'alpha': 0.7},
#                 line_kws={'color': 'red'})
    
#     plt.title(f"{feature.replace('_', ' ').title()} vs 2025 Rank\n$R^2$ = {r2:.2f}")
#     plt.xlabel(feature.replace('_', ' ').title())
#     plt.ylabel("2025 Rank")
#     plt.grid(True)
#     plt.ylim(max_rank + 50, 1)
#     plt.yticks(ticks)
#     plt.tight_layout()
#     plt.show()

# Step 17: Top Improved
top_improved = df_cleaned.sort_values(by='rank_improvement', ascending=False).head(10)
print("Top 10 Universities with Biggest Rank Improvements:")
print(top_improved[['institution_name', '2024_rank', '2025_rank', 'rank_improvement']])


# Step 20: Top 10 universities with biggest rank improvements
top_improved = df_cleaned.sort_values(by='rank_improvement', ascending=False).head(10)

print("\nTop 10 Universities with Biggest Rank Improvements:")
print(top_improved[['institution_name', '2024_rank', '2025_rank', 'rank_improvement']])

# Data
institutions = top_improved['institution_name']
rank_2024 = top_improved['2024_rank']
rank_2025 = top_improved['2025_rank']

x = np.arange(len(institutions))
width = 0.35

# Plot
fig, ax = plt.subplots(figsize=(12, 6))
rects1 = ax.bar(x - width/2, rank_2024, width, label='2024 Rank', color='skyblue')
rects2 = ax.bar(x + width/2, rank_2025, width, label='2025 Rank', color='lightgreen')

# Titles and labels
ax.set_ylabel('Rank')
ax.set_title('Top 10 Universities with Biggest Rank Improvements (2024 vs 2025)')
ax.set_xticks(x)
ax.set_xticklabels(institutions, rotation=45, ha='right')
ax.legend()
ax.grid(True, axis='y')

# Invert y-axis so better ranks (lower numbers) are at the top
plt.gca().invert_yaxis()

# Annotate bars with values
for rect in rects1 + rects2:
    height = rect.get_height()
    ax.annotate(f'{int(height)}',
                xy=(rect.get_x() + rect.get_width() / 2, height),
                xytext=(0, 5),
                textcoords="offset points",
                ha='center', va='bottom', fontsize=8)

plt.tight_layout()
plt.show()



# Step 19: Top 10 universities with biggest rank drops (negative improvement)
top_dropped = df_cleaned.sort_values(by='rank_improvement').head(10)  # most negative values

print("\nTop 10 Universities with Biggest Rank Drops:")
print(top_dropped[['institution_name', '2024_rank', '2025_rank', 'rank_improvement']])

# Data
institutions = top_dropped['institution_name']
rank_2024 = top_dropped['2024_rank']
rank_2025 = top_dropped['2025_rank']

x = np.arange(len(institutions))  # label locations
width = 0.35  # bar width

# Plot
fig, ax = plt.subplots(figsize=(12, 6))
rects1 = ax.bar(x - width/2, rank_2024, width, label='2024 Rank', color='skyblue')
rects2 = ax.bar(x + width/2, rank_2025, width, label='2025 Rank', color='salmon')

# Titles and labels
ax.set_ylabel('Rank')
ax.set_title('Top 10 Universities with Biggest Rank Drops (2024 vs 2025)')
ax.set_xticks(x)
ax.set_xticklabels(institutions, rotation=45, ha='right')
ax.legend()
ax.grid(True, axis='y')

# Invert y-axis since rank 1 is best
plt.gca().invert_yaxis()

# Annotate bars with values
for rect in rects1 + rects2:
    height = rect.get_height()
    ax.annotate(f'{int(height)}',
                xy=(rect.get_x() + rect.get_width() / 2, height),
                xytext=(0, 5),
                textcoords="offset points",
                ha='center', va='bottom', fontsize=8)

plt.tight_layout()
plt.show()
