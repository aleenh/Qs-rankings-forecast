import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing

# Load dataset
df = pd.read_csv("university.csv")

# Get ranking columns
rank_columns = [col for col in df.columns if col.startswith("Rank_")]
rank_columns.sort()

# Store forecasts and diagnostics
multi_year_forecasts = []

# Forecast loop
for _, row in df.iterrows():
    name = row['Name']
    ts = row[rank_columns].values

    try:
        # Fit ETS model
        model = ExponentialSmoothing(ts, trend='add', seasonal=None)
        fit = model.fit()

        # Forecast 3 years
        forecast = fit.forecast(3)
        forecast_2026, forecast_2027, forecast_2028 = forecast

        # Diagnostics
        aic = fit.aic
        bic = fit.bic
        sse = fit.sse

    except:
        forecast_2026 = forecast_2027 = forecast_2028 = None
        aic = bic = sse = None

    # Store results
    multi_year_forecasts.append({
        'Name': name,
        'Rank_2026': forecast_2026,
        'Rank_2027': forecast_2027,
        'Rank_2028': forecast_2028,
    })

# Convert to DataFrame
forecast_df = pd.DataFrame(multi_year_forecasts)

# Round and cap the ranks
forecast_df[['Rank_2026', 'Rank_2027', 'Rank_2028']] = (
    forecast_df[['Rank_2026', 'Rank_2027', 'Rank_2028']]
    .round(0)
    .clip(lower=1)
    .astype('Int64')
)

print(forecast_df.head().to_string(index=False))

# Merge with original dataset
merged_df = pd.merge(df, forecast_df, on='Name')

# Save to CSV
merged_df.to_csv("ETS_full_forecast_with_diagnostics.csv", index=False, encoding='utf-8-sig')

# Plot for 5 sample universities
years = list(range(2016, 2029))
sample = merged_df.head(5)

for _, row in sample.iterrows():
    past_ranks = [row[f'Rank_{y}'] for y in range(2016, 2026)]
    future_ranks = [row['Rank_2026'], row['Rank_2027'], row['Rank_2028']]
    full_ranks = past_ranks + future_ranks

    plt.plot(years, full_ranks, marker='o', label=row['Name'])
plt.axvline(2025.5, color='gray', linestyle='--', label='Forecast starts')
plt.xlabel("Year")
plt.ylabel("Rank")
plt.title("ETS Forecasted University Ranks (2026–2028)")
plt.gca().invert_yaxis()
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# Forecasting using Facebook Prophet
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from prophet import Prophet

# Load dataset
df = pd.read_csv("university.csv")

# Historical and forecast columns
rank_cols = [f"Rank_{year}" for year in range(2016, 2026)]
future_years = [2026, 2027, 2028]

# Forecast storage
prophet_forecasts = []

# Loop through each university
for _, row in df.iterrows():
    name = row['Name']
    ranks = row[rank_cols].values.astype(float)

    # Skip invalid data
    if np.isnan(ranks).any() or np.all(ranks == ranks[0]):
        continue

    # Prepare Prophet format time series
    ts = pd.DataFrame({
        'ds': pd.date_range(start='2016-01-01', periods=10, freq='Y'),
        'y': ranks
    })

    try:
        model = Prophet(daily_seasonality=False, yearly_seasonality=False, weekly_seasonality=False)
        model.fit(ts)

        # Forecast for 2026–2028
        future = pd.date_range(start='2026-01-01', periods=3, freq='Y')
        future_df = pd.DataFrame({'ds': future})
        forecast = model.predict(future_df)

        forecasted = forecast['yhat'].round(0).clip(lower=1).astype(int).tolist()

        prophet_forecasts.append({
            'Name': name,
            'Rank_2026': forecasted[0],
            'Rank_2027': forecasted[1],
            'Rank_2028': forecasted[2]
        })

    except:
        continue

# Convert to DataFrame and save
prophet_df = pd.DataFrame(prophet_forecasts)
prophet_df.to_csv("prophet_forecast_2026_2028.csv", index=False, encoding='utf-8-sig')
print(prophet_df.head())

# Merge forecast with original data for plotting
merged_prophet_df = pd.merge(df, prophet_df, on='Name')

# Plot for selected universities
selected_unis = ['Aalborg University', 'Aalto University', 'Aarhus University',
                 'Aberystwyth University', 'Aix-Marseille University']
sample = merged_prophet_df[merged_prophet_df['Name'].isin(selected_unis)]
years = list(range(2016, 2029))

plt.figure(figsize=(8, 6))
for _, row in sample.iterrows():
    past = [row[f'Rank_{y}'] for y in range(2016, 2026)]
    future = [row['Rank_2026'], row['Rank_2027'], row['Rank_2028']]
    full = past + future
    plt.plot(years, full, marker='o', label=row['Name'])
plt.axvline(2025.5, color='gray', linestyle='--', label='Forecast starts')
plt.xlabel("Year")
plt.ylabel("Rank")
plt.title("Prophet Forecasted University Ranks (2026–2028)")
plt.gca().invert_yaxis()
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


#LINEAR REGRESSION
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

# Load your dataset
df = pd.read_csv("university.csv")

# Get rank columns and ensure correct order
rank_columns = [col for col in df.columns if col.startswith("Rank_")]
rank_columns.sort()

# Extract years from column names
years = np.array([int(col.split("_")[1]) for col in rank_columns]).reshape(-1, 1)

# List to store forecast results
linear_forecasts = []

for _, row in df.iterrows():
    name = row['Name']
    ranks = row[rank_columns].values.astype(float)

    try:
        # Fit Linear Regression model
        model = LinearRegression()
        model.fit(years, ranks)

        # Predict for future years
        future_years = np.array([[2026], [2027], [2028]])
        predictions = model.predict(future_years).clip(min=1)

        # Round predictions to nearest integer
        forecast_2026, forecast_2027, forecast_2028 = np.round(predictions).astype(int)
    except Exception as e:
        print(f" Failed for {name}: {e}")
        forecast_2026 = forecast_2027 = forecast_2028 = None

    linear_forecasts.append({
        'Name': name,
        'Rank_2026': forecast_2026,
        'Rank_2027': forecast_2027,
        'Rank_2028': forecast_2028
    })

# Convert to DataFrame
linear_df = pd.DataFrame(linear_forecasts)

# Save results to CSV
linear_df.to_csv("linear_forecast_2026_2028.csv", index=False, encoding='utf-8-sig')

# Print sample output
print(linear_df.head())


import matplotlib.pyplot as plt

# Plot for selected universities
selected_unis = ['Aalborg University', 'Aalto University', 'Aarhus University',
                 'Aberystwyth University', 'Aix-Marseille University']
sample = merged_prophet_df[merged_prophet_df['Name'].isin(selected_unis)]
years = list(range(2016, 2029))

plt.figure(figsize=(8, 6))
for _, row in sample.iterrows():
    past = [row[f'Rank_{y}'] for y in range(2016, 2026)]
    future = [row['Rank_2026'], row['Rank_2027'], row['Rank_2028']]
    full = past + future
    plt.plot(years, full, marker='o', label=row['Name'])
plt.axvline(2025.5, color='gray', linestyle='--', label='Forecast starts')
plt.xlabel("Year")
plt.ylabel("Rank")
plt.title("Linear Regression University Ranks (2026–2028)")
plt.gca().invert_yaxis()
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()