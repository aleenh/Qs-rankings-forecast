import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

# Load cleaned data
df = pd.read_csv("cleanedData.csv")

# Features and Target
features = [
    'academic_reputation', 'employer_reputation', 'employment_outcomes',
    'sustainability', 'citations_per_faculty', 'international_research_network',
    'international_students', 'international_faculty', 'faculty_student'
]
X = df[features]
y = df['2025_rank']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize for Linear Regression
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Initialize models
models = {
    'Linear Regression': LinearRegression(),
    'Random Forest': RandomForestRegressor(n_estimators=100, random_state=42),
    'Gradient Boosting': GradientBoostingRegressor(n_estimators=100, random_state=42)
}

results = []
predictions = {}

# Fit models, evaluate, and collect predictions
for name, model in models.items():
    if name == 'Linear Regression':
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        scores = cross_val_score(model, scaler.transform(X), y, cv=5, scoring='r2')
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        scores = cross_val_score(model, X, y, cv=5, scoring='r2')
    
    # Store predictions and results
    predictions[name] = y_pred
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    results.append((name, rmse, mae, r2, scores.mean()))

    # Scatter Plot: Actual vs Predicted
    plt.figure(figsize=(8, 6))
    sns.scatterplot(x=y_test, y=y_pred, color="orange", alpha=0.7, s=60, edgecolor="black")
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', linewidth=2)
    plt.title(f"{name} - Actual vs Predicted", fontsize=14, fontweight='bold')
    plt.xlabel("Actual 2025 Rank")
    plt.ylabel("Predicted 2025 Rank")
    plt.gca().invert_xaxis()
    plt.gca().invert_yaxis()
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()

    # Residual Plot
    residuals = y_test - y_pred
    plt.figure(figsize=(8, 5))
    sns.histplot(residuals, kde=True, color="orange", edgecolor="black", bins=30)
    plt.title(f"{name} - Residual Distribution", fontsize=14, fontweight='bold')
    plt.xlabel("Prediction Error")
    plt.ylabel("Count")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()

# Feature Importances (Tree Models)
for name in ['Random Forest', 'Gradient Boosting']:
    model = models[name]
    importances = pd.Series(model.feature_importances_, index=features).sort_values()
    
    plt.figure(figsize=(9, 6))
    ax = sns.barplot(x=importances.values, y=importances.index, palette="crest", edgecolor="black")
    for i, v in enumerate(importances.values):
        ax.text(v + 0.005, i, f"{v:.2f}", color='black', va='center', fontweight='bold')
    plt.title(f"{name} - Feature Importance", fontsize=16, fontweight='bold')
    plt.xlabel("Importance Score")
    plt.ylabel("Feature")
    plt.grid(True, linestyle='--', alpha=0.3)
    plt.tight_layout()
    plt.show()

# Results Summary
results_df = pd.DataFrame(results, columns=['Model', 'RMSE', 'MAE', 'R² (test)', 'CV R² (mean)'])
results_df_sorted = results_df.sort_values(by='RMSE')
print("\nModel Performance Summary:")
print(results_df_sorted)

# Comparison Plots
sns.set_theme(style="whitegrid")
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# RMSE
sns.barplot(data=results_df_sorted, x='Model', y='RMSE', ax=axes[0], palette='rocket', edgecolor='black')
axes[0].set_title("RMSE (↓ Better)", fontsize=13, fontweight='bold')

# MAE
sns.barplot(data=results_df_sorted, x='Model', y='MAE', ax=axes[1], palette='crest', edgecolor='black')
axes[1].set_title("MAE (↓ Better)", fontsize=13, fontweight='bold')

# R²
sns.barplot(data=results_df_sorted, x='Model', y='R² (test)', ax=axes[2], palette='mako', edgecolor='black')
axes[2].set_title("R² Score (↑ Better)", fontsize=13, fontweight='bold')

# Clean axes
for ax in axes:
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.grid(True, linestyle='--', alpha=0.3)

plt.suptitle("Model Performance Comparison", fontsize=16, fontweight='bold')
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()


# Fit and evaluate each model
# for name, model in models.items():
#     if name == 'Linear Regression':
#         model.fit(X_train_scaled, y_train)
#         y_pred = model.predict(X_test_scaled)
#         scores = cross_val_score(model, scaler.transform(X), y, cv=5, scoring='r2')
#     else:
#         model.fit(X_train, y_train)
#         y_pred = model.predict(X_test)
#         scores = cross_val_score(model, X, y, cv=5, scoring='r2')
    
#     rmse = mean_squared_error(y_test, y_pred, squared=False)
#     mae = mean_absolute_error(y_test, y_pred)
#     r2 = r2_score(y_test, y_pred)
#     results.append((name, rmse, mae, r2, scores.mean()))
#     predictions[name] = y_pred

#     # Scatter plot: Actual vs Predicted
#     plt.figure(figsize=(6, 5))
#     plt.scatter(y_test, y_pred, alpha=0.6)
#     plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')
#     plt.xlabel('Actual 2025 Rank')
#     plt.ylabel('Predicted 2025 Rank')
#     plt.title(f"{name} - Actual vs Predicted")
#     plt.gca().invert_xaxis()
#     plt.gca().invert_yaxis()
#     plt.grid(True)
#     plt.tight_layout()
#     plt.show()

#     # Residual plot
#     residuals = y_test - y_pred
#     plt.figure(figsize=(6, 4))
#     sns.histplot(residuals, kde=True, bins=30)
#     plt.title(f"{name} - Residuals")
#     plt.xlabel("Prediction Error")
#     plt.grid(True)
#     plt.tight_layout()
#     plt.show()

# # Results summary
# results_df = pd.DataFrame(results, columns=['Model', 'RMSE', 'MAE', 'R² (test)', 'CV R² (mean)'])
# print("\n🔍 Model Performance Summary:")
# print(results_df.sort_values(by='RMSE'))

# # Feature Importances for tree models
# for name in ['Random Forest', 'Gradient Boosting']:
#     model = models[name]
#     importance = pd.Series(model.feature_importances_, index=features)
#     importance.sort_values().plot(kind='barh', figsize=(8, 5), title=f"{name} - Feature Importance")
#     plt.xlabel("Importance Score")
#     plt.tight_layout()
#     plt.show()

