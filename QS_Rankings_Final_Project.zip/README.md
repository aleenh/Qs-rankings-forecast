# Predicting QS World University Rankings (Final Year Project)

This repository contains my final year university project focused on predicting QS World University Rankings using data science techniques, including preprocessing, clustering, classification, and time series forecasting.

## 📂 Project Structure

- `Preprocessing.py` – Data cleaning and transformation
- `Clustering.py` – K-Means, DBSCAN, and Hierarchical clustering on universities
- `Prediction.py` – Rank prediction using Gradient Boosting, Random Forest, and Linear Regression
- `Classification.py` – Rank class prediction using Logistic Regression, Random Forest, SVM, and XGBoost
- `TimeSeries.py` – Forecasting university ranks using ETS, Prophet, and Linear Regression
- `cleanedData.csv` – Final processed dataset used in analysis
- `university.csv` – Raw data including rank history from 2016 to 2025

## 🛠 Tools and Technologies

- Python, pandas, NumPy, matplotlib, seaborn, scikit-learn, XGBoost
- Facebook Prophet, statsmodels (ETS), Plotly, GeoPandas

## 🔍 Goals

- Clean and preprocess QS ranking data
- Cluster universities by similar performance indicators
- Predict 2025 rankings and classify universities into rank categories
- Forecast future rankings from 2026 to 2028 using time series models

## 👤 Author

**Aleen Hoblos & Jana Al Jamal**  
[LinkedIn](https://www.linkedin.com/in/aleen-hoblos-49913a336?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app)
