import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt
import seaborn as sns
from xgboost import XGBClassifier 
from xgboost import XGBClassifier, plot_importance
from sklearn.model_selection import cross_val_score, GridSearchCV
from sklearn.metrics import accuracy_score, f1_score
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
from sklearn.multiclass import OneVsRestClassifier



# Load the cleaned dataset
df = pd.read_csv("cleanedData.csv")

# 1. Create classification target based on 2025_rank
def rank_category(rank):
    if rank <= 100:
        return 'Top 100'
    elif rank <= 400:
        return '101–400'
    else:
        return '401+'

df['rank_class'] = df['2025_rank'].apply(rank_category)

# 2. Select features
features = [
    'academic_reputation', 'employer_reputation', 'employment_outcomes',
    'sustainability', 'citations_per_faculty', 'international_research_network',
    'international_students', 'international_faculty', 'faculty_student'
]

X = df[features]
y = df['rank_class']

# 3. Encode target variable
y_encoded = y.astype('category').cat.codes
label_mapping = dict(enumerate(y.astype('category').cat.categories))




# 4. Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded)

# 5. Standardize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 6. Define classifiers
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
    'SVM': SVC(kernel='rbf', probability=True),
    'XGBoost': XGBClassifier( eval_metric='mlogloss', random_state=42)
}


# 7. Train and evaluate
for name, model in models.items():
    print(f"\n Training and Evaluating: {name}")
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)

    print("\n Classification Report:")
    print(classification_report(y_test, y_pred, target_names=label_mapping.values()))

    # Confusion Matrix
    disp = ConfusionMatrixDisplay(confusion_matrix=confusion_matrix(y_test, y_pred,normalize='true'),
                                  display_labels=label_mapping.values())
    disp.plot(cmap='Blues')
    plt.title(f"{name} – Confusion Matrix")
    plt.grid(False)
    plt.show()

    # Cross-validation scores
    acc_scores = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring='accuracy')
    f1_scores = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring='f1_weighted')

    print(f" Cross-Validation Accuracy (mean ± std): {acc_scores.mean():.3f} ± {acc_scores.std():.3f}")
    print(f" Cross-Validation F1-score (mean ± std): {f1_scores.mean():.3f} ± {f1_scores.std():.3f}")


    if name == 'Random Forest':
        importances = model.feature_importances_
        sns.barplot(x=importances, y=features)
        plt.title("Random Forest Feature Importance")
        plt.show()



    # Feature Importance for XGBoost
    if name == 'XGBoost':
        plt.figure(figsize=(10, 6))
        plot_importance(model, importance_type='gain', title='XGBoost Feature Importance (by Gain)', 
                        grid=True, show_values=False, height=0.5)
        plt.tight_layout()
        plt.show()

param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.01, 0.1, 0.2],
    'subsample': [0.8, 1]
}

xgb_grid = GridSearchCV(
    XGBClassifier(eval_metric='mlogloss', random_state=42),
    param_grid,
    cv=5,
    scoring='f1_weighted',
    verbose=1,
    n_jobs=-1
)

print("\n Starting XGBoost hyperparameter tuning...")
xgb_grid.fit(X_train_scaled, y_train)

print(f"\n Best Parameters: {xgb_grid.best_params_}")
print(f" Best CV Score (F1): {xgb_grid.best_score_:.4f}")

# Evaluate tuned model
best_xgb = xgb_grid.best_estimator_
y_pred_best = best_xgb.predict(X_test_scaled)
print("\n Tuned XGBoost Classification Report:")
print(classification_report(y_test, y_pred_best, target_names=label_mapping.values()))


results = []

for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='weighted')
    results.append({'Model': name, 'Accuracy': acc, 'F1-score': f1})

# Add tuned XGBoost
y_pred_best = best_xgb.predict(X_test_scaled)
results.append({
    'Model': 'Tuned XGBoost',
    'Accuracy': accuracy_score(y_test, y_pred_best),
    'F1-score': f1_score(y_test, y_pred_best, average='weighted')
})

results_df = pd.DataFrame(results)
print("\nFinal Model Comparison Summary:")
print(results_df)

sns.countplot(x=y)
plt.title("Target Class Distribution")
plt.show()


# ROC Curve (multi-class)
y_bin = label_binarize(y_test, classes=[0, 1, 2])
n_classes = y_bin.shape[1]

classifier = OneVsRestClassifier(LogisticRegression(max_iter=1000))
y_score = classifier.fit(X_train_scaled, y_train).predict_proba(X_test_scaled)

fpr = dict()
tpr = dict()
roc_auc = dict()

for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_bin[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Plot all ROC curves
plt.figure(figsize=(8, 6))
for i in range(n_classes):
    plt.plot(fpr[i], tpr[i], label=f"Class {i} (AUC = {roc_auc[i]:.2f})")
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Multi-Class ROC Curve (Logistic Regression)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


# Display top universities per class
for cls in df['rank_class'].unique():
    print(f"\n Sample Universities in '{cls}' Class:")
    print(df[df['rank_class'] == cls][['institution_name', '2025_rank']].sort_values('2025_rank').head(10))
    
# Pie chart for rank class
df['rank_class'].value_counts().plot.pie(autopct='%1.1f%%', startangle=90, colors=sns.color_palette('pastel'))
plt.title("Distribution of Universities by 2025 Rank Class")
plt.ylabel('')
plt.show()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import (
    classification_report, confusion_matrix, ConfusionMatrixDisplay,
    accuracy_score, f1_score, roc_curve, auc
)
from sklearn.inspection import permutation_importance
from sklearn.multiclass import OneVsRestClassifier
from xgboost import XGBClassifier, plot_importance

# Load and prepare the dataset
df = pd.read_csv("cleanedData.csv")

def rank_category(rank):
    if rank <= 100:
        return 'Top 100'
    elif rank <= 400:
        return '101–400'
    else:
        return '401+'

df['rank_class'] = df['2025_rank'].apply(rank_category)

features = [
    'academic_reputation', 'employer_reputation', 'employment_outcomes',
    'sustainability', 'citations_per_faculty', 'international_research_network',
    'international_students', 'international_faculty', 'faculty_student'
]
X = df[features]
y = df['rank_class']
y_encoded = y.astype('category').cat.codes
label_mapping = dict(enumerate(y.astype('category').cat.categories))

X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

models = {
    'Logistic Regression': LogisticRegression(max_iter=1000),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
    'SVM': SVC(kernel='rbf', probability=True),
    'XGBoost': XGBClassifier(eval_metric='mlogloss', random_state=42)
}

for name, model in models.items():
    print(f"\n{name}")
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)

    print(classification_report(y_test, y_pred, target_names=label_mapping.values()))

    disp = ConfusionMatrixDisplay(confusion_matrix=confusion_matrix(y_test, y_pred, normalize='true'),
                                  display_labels=label_mapping.values())
    disp.plot(cmap='Blues')
    plt.title(f"{name} – Confusion Matrix")
    plt.grid(False)
    plt.show()

    # Feature importance plotting (standardized for all models)
    if name == 'Random Forest':
        importance = model.feature_importances_
        sns.barplot(x=importance, y=features)
        plt.title("Random Forest Feature Importance")
        plt.tight_layout()
        plt.show()

    elif name == 'XGBoost':
        model.get_booster().feature_names = features
        plt.figure(figsize=(10, 6))
        plot_importance(model, importance_type='gain', title='XGBoost Feature Importance (by Gain)',
                        grid=True, show_values=False, height=0.5)
        plt.tight_layout()
        plt.show()

    elif name == 'Logistic Regression':
        importance = np.abs(model.coef_).mean(axis=0)
        sns.barplot(x=importance, y=features)
        plt.title("Logistic Regression Feature Importance (mean |coefficients|)")
        plt.tight_layout()
        plt.show()

    elif name == 'SVM':
        result = permutation_importance(model, X_test_scaled, y_test, n_repeats=10,
                                        random_state=42, scoring='f1_weighted')
        importance = result.importances_mean
        sns.barplot(x=importance, y=features)
        plt.title("SVM Feature Importance (Permutation-based)")
        plt.tight_layout()
        plt.show()




