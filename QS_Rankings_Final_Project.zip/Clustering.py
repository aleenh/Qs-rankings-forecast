from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
import plotly.express as px
import plotly.io as pio
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np


df_cleaned = pd.read_csv("cleanedData.csv")
# Step 1: Select features
features_for_clustering = [
    'academic_reputation', 'employer_reputation', 'employment_outcomes',
    'sustainability', 'citations_per_faculty', 'international_research_network',
    'international_students', 'international_faculty', 'faculty_student'
]
X = df_cleaned[features_for_clustering].dropna()

# Step 2: Clustering function
def clustering_results(X_scaled):
    inertia, silhouette = [], []
    for k in range(2, 11):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        kmeans.fit(X_scaled)
        inertia.append(kmeans.inertia_)
        silhouette.append(silhouette_score(X_scaled, kmeans.labels_))
    return inertia, silhouette

# Step 3: StandardScaler
scaler_std = StandardScaler()
X_std = scaler_std.fit_transform(X)
inertia_std, silhouette_std = clustering_results(X_std)

# Step 4: MinMaxScaler
scaler_minmax = MinMaxScaler()
X_minmax = scaler_minmax.fit_transform(X)
inertia_minmax, silhouette_minmax = clustering_results(X_minmax)

# Step 5: Plot
k_range = range(2, 11)
plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
plt.plot(k_range, inertia_std, marker='o', label='StandardScaler')
plt.plot(k_range, inertia_minmax, marker='s', label='MinMaxScaler')
plt.title('Elbow Method (Inertia Comparison)')
plt.xlabel('k')
plt.ylabel('Inertia')
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(k_range, silhouette_std, marker='o', label='StandardScaler')
plt.plot(k_range, silhouette_minmax, marker='s', label='MinMaxScaler')
plt.title('Silhouette Score Comparison')
plt.xlabel('k')
plt.ylabel('Silhouette Score')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()

# Step 6: Print metrics per k
print(f"\n{'k':<5}{'Inertia (Std)':<20}{'Silhouette (Std)':<25}{'Inertia (MinMax)':<20}{'Silhouette (MinMax)'}")
for i, k in enumerate(k_range):
    print(f"{k:<5}{inertia_std[i]:<20.2f}{silhouette_std[i]:<25.4f}{inertia_minmax[i]:<20.2f}{silhouette_minmax[i]:.4f}")

print(f"\nBest Silhouette Score (StandardScaler): {max(silhouette_std):.4f}")
print(f"Best Silhouette Score (MinMaxScaler): {max(silhouette_minmax):.4f}")

# Step 7: PCA Plot for best k ( k=2)
k_best = 2
kmeans = KMeans(n_clusters=k_best, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_std)

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_std)

plt.figure(figsize=(8, 6))
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels, cmap='Set1', alpha=0.7)
plt.title(f"KMeans Clustering with PCA (k={k_best})")
plt.xlabel("PCA 1")
plt.ylabel("PCA 2")
plt.legend(*scatter.legend_elements(), title="Cluster")
plt.grid(True)
plt.tight_layout()
plt.show()

# Step 8: Assign cluster
df_clustered = df_cleaned.copy()
df_clustered['cluster'] = labels

# Step 9: Show feature means per cluster
cluster_means = df_clustered.groupby('cluster')[features_for_clustering].mean()
print("\nMean feature values per cluster:")
print(cluster_means)

# Step 10: Sample institutions
print("\nSample from Cluster 0:")
print(df_clustered[df_clustered['cluster'] == 0][['institution_name', 'size', 'location_full', '2025_rank']].head(10))

print("\nSample from Cluster 1:")
print(df_clustered[df_clustered['cluster'] == 1][['institution_name', 'size', 'location_full', '2025_rank']].head(10))

# Step 11: Plotly Map (optional)
pio.renderers.default = 'browser'
size_map = {'XS': 5, 'S': 10, 'M': 15, 'L': 20, 'XL': 25}
df_clustered['size_value'] = df_clustered['size'].map(size_map)

fig = px.scatter_geo(
    df_clustered,
    locations="location_full",
    locationmode="country names",
    color="cluster",
    size="size_value",
    hover_name="institution_name",
    projection="natural earth",
    title="Universities by Cluster (Using 2025 Rank and Features)",
    opacity=0.7
)
fig.update_layout(legend_title_text="Cluster")
fig.show()

# Step 12: Mean 2025 Rank per cluster
print("\nAverage 2025 Rank per cluster:")
print(df_clustered.groupby('cluster')['2025_rank'].mean())


import seaborn as sns

sns.boxplot(data=df_clustered, x='cluster', y='2025_rank')
plt.title("Distribution of 2025 Rank by Cluster")
plt.ylabel("2025 Rank")
plt.xlabel("Cluster")
plt.grid(True)
plt.show()


# Step 13: Evaluation metrics
sil = silhouette_score(X_std, labels)
dbi = davies_bouldin_score(X_std, labels)
ch = calinski_harabasz_score(X_std, labels)

print("\nClustering Evaluation Metrics (k=2):")
print(f"Silhouette Score: {sil:.4f}")
print(f"Davies-Bouldin Index: {dbi:.4f} (lower is better)")
print(f"Calinski-Harabasz Score: {ch:.2f} (higher is better)")

























#DBSCAN 
# 2) DBSCAN clustering.

# Step 1: Function to plot K-distance graph
def plot_k_distance(X_scaled, min_samples=10):
    from sklearn.neighbors import NearestNeighbors
    neighbors = NearestNeighbors(n_neighbors=min_samples)
    neighbors_fit = neighbors.fit(X_scaled)
    distances, indices = neighbors_fit.kneighbors(X_scaled)
    distances = np.sort(distances[:, min_samples-1])
    
    plt.figure(figsize=(8, 6))
    plt.plot(distances)
    plt.title('K-distance Graph (for choosing eps)')
    plt.xlabel('Points sorted by distance')
    plt.ylabel(f'{min_samples}th Nearest Neighbor Distance')
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# Step 2: Function to run DBSCAN and return labels, silhouette, number of clusters, and noise points
def run_dbscan(X_scaled, eps, min_samples=10):
    from sklearn.cluster import DBSCAN
    from sklearn.metrics import silhouette_score
    import numpy as np
    
    dbscan = DBSCAN(eps=eps, min_samples=min_samples)
    labels = dbscan.fit_predict(X_scaled)
    
    if len(set(labels)) > 1:
        silhouette = silhouette_score(X_scaled, labels)
    else:
        silhouette = -1  # if only noise or single cluster
    
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise = np.sum(labels == -1)
    
    return labels, silhouette, n_clusters, n_noise

# Step 3: StandardScaler scaling
from sklearn.preprocessing import StandardScaler

scaler_std = StandardScaler()
X_std = scaler_std.fit_transform(X)

plot_k_distance(X_std)

# Step 4: Run DBSCAN using the best config from tuning
eps_std = 1.4
min_samples_std = 5

labels_std, silhouette_std, n_clusters_std, n_noise_std = run_dbscan(X_std, eps=eps_std, min_samples=min_samples_std)

# Update cluster labels in DataFrame
df_clustered['dbscan_cluster'] = labels_std

# Step 5: Output nicely
print("\n DBSCAN Results with StandardScaler:")
print(f" - Epsilon (eps): {eps_std}")
print(f" - Min Samples: {min_samples_std}")
print(f" - Silhouette Score: {silhouette_std:.4f}")
print(f" - Number of Clusters (excluding noise): {n_clusters_std}")
print(f" - Number of Noise Points: {n_noise_std}")

# Step 6: Apply PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_std)  # Use X_std because you used StandardScaler

# Step 7: Plot the clusters
plt.figure(figsize=(10, 6))
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=labels_std, cmap='Set1', alpha=0.7)
plt.title("DBSCAN Clustering Visualization (PCA 2D)")
plt.xlabel("PCA Component 1")
plt.ylabel("PCA Component 2")
plt.grid(True)

# Add legend
handles, labels_unique = scatter.legend_elements()
plt.legend(handles, labels_unique, title="Cluster")

plt.tight_layout()
plt.show()

# Assign labels to the dataset
df_clustered = df_cleaned.copy()
df_clustered['dbscan_cluster'] = labels_std  # from your DBSCAN result

# Important columns to show
columns_to_show = ['institution_name', 'size', 'location_full', 'dbscan_cluster']

# Sample universities per cluster (excluding noise)
for cluster_label in sorted(df_clustered['dbscan_cluster'].unique()):
    if cluster_label != -1:
        print(f"\n Sample Universities from Cluster {cluster_label}:\n")
        print(df_clustered[df_clustered['dbscan_cluster'] == cluster_label][columns_to_show].head(10).to_string(index=False))

# Calculate mean feature values per cluster
mean_features_per_cluster = df_clustered[df_clustered['dbscan_cluster'] != -1].groupby('dbscan_cluster')[features_for_clustering].mean()

print("\n Mean feature values per DBSCAN cluster:")
print(mean_features_per_cluster)

# Map size categories to marker sizes
size_mapping = {'XS': 5, 'S': 10, 'M': 15, 'L': 20, 'XL': 25}
df_clustered['size_value'] = df_clustered['size'].map(size_mapping)

# Geographical map (excluding noise points)
fig = px.scatter_geo(
    df_clustered[df_clustered['dbscan_cluster'] != -1],  # exclude noise
    locations="location_full",
    locationmode="country names",
    color="dbscan_cluster",
    size="size_value",
    hover_name="institution_name",
    projection="natural earth",
    title="DBSCAN Geographical Map of Universities by Cluster and Size",
    opacity=0.7
)

fig.update_layout(legend_title_text='DBSCAN Cluster')
fig.show()

# DBSCAN: 2025 Rank per Cluster
print("\n DBSCAN: 2025 Rank per Cluster (Lower is Better)")
print(df_clustered[df_clustered['dbscan_cluster'] != -1].groupby('dbscan_cluster')['2025_rank'].mean())

# DBSCAN: Evaluation Metrics 
dbscan_sil = silhouette_score(X_std[labels_std != -1], labels_std[labels_std != -1])
dbscan_db = davies_bouldin_score(X_std[labels_std != -1], labels_std[labels_std != -1])
dbscan_ch = calinski_harabasz_score(X_std[labels_std != -1], labels_std[labels_std != -1])
print("\n DBSCAN Evaluation Metrics:")
print(f"Silhouette Score: {dbscan_sil:.4f}")
print(f"Davies-Bouldin Index: {dbscan_db:.4f} (lower is better)")
print(f"Calinski-Harabasz Score: {dbscan_ch:.2f} (higher is better)")


filtered_X = X_std[labels_std != -1]
filtered_labels = labels_std[labels_std != -1]

n_clusters_detected = len(set(filtered_labels))

if n_clusters_detected > 1:
    dbscan_sil = silhouette_score(filtered_X, filtered_labels)
    dbscan_db = davies_bouldin_score(filtered_X, filtered_labels)
    dbscan_ch = calinski_harabasz_score(filtered_X, filtered_labels)

    print("\nDBSCAN Evaluation Metrics:")
    print(f"Silhouette Score: {dbscan_sil:.4f}")
    print(f"Davies-Bouldin Index: {dbscan_db:.4f} (lower is better)")
    print(f"Calinski-Harabasz Score: {dbscan_ch:.2f} (higher is better)")
else:
    print("\n⚠️ DBSCAN found fewer than 2 clusters — evaluation metrics not applicable.")


# Your DBSCAN output is not suitable for evaluating cluster performance using 2025_rank, because there’s only one cluster (and outliers), which breaks evaluation metrics and group-wise analysis like:

# python
# Copy
# Edit
# df_clustered[df_clustered['dbscan_cluster'] != -1].groupby('dbscan_cluster')['2025_rank'].mean()

print("\nTrying multiple DBSCAN settings:")
for eps in [1.0, 1.2, 1.4, 1.6]:
    for min_samples in [3, 5]:
        labels, sil, n_clust, n_noise = run_dbscan(X_std, eps=eps, min_samples=min_samples)
        print(f"eps={eps}, min_samples={min_samples} → clusters={n_clust}, silhouette={sil:.4f}, noise={n_noise}")
#Run DBSCAN with eps=1.4, min_samples=5

 #The DBSCAN clustering (using academic and performance features) 
# identified 6 distinct groups of universities.
#  Clusters 0, 1, and 2 represent globally high-ranking institutions, 
#  with average 2025 QS ranks below 35. Clusters 4 and 5 represent mid-performing institutions,
#  while Cluster 3 includes the lowest-ranked group, averaging around 850. 
#  This segmentation provides insight into performance tiers beyond raw ranking, 
#  showing patterns based on key QS indicators.








import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.decomposition import PCA

# Load cleaned data
df = pd.read_csv("cleanedData.csv")

features_for_clustering = [
    'academic_reputation', 'employer_reputation', 'employment_outcomes',
    'sustainability', 'citations_per_faculty', 'international_research_network',
    'international_students', 'international_faculty', 'faculty_student'
]

# Helper function to find best cut height
def find_best_cut(linkage_matrix, X_scaled, min_h=5, max_h=25):
    best_score = -1
    best_cut = None
    best_labels = None
    for h in range(min_h, max_h):
        labels = fcluster(linkage_matrix, t=h, criterion='distance')
        if len(set(labels)) < 2 or len(set(labels)) >= len(X_scaled):
            continue
        score = silhouette_score(X_scaled, labels)
        if score > best_score:
            best_score = score
            best_cut = h
            best_labels = labels
    return best_cut, best_score, best_labels

# Sample 50 universities
df_sample = df.sample(n=50, random_state=42).reset_index(drop=True)
X_sample = df_sample[features_for_clustering].dropna()
scaler = StandardScaler()
X_sample_scaled = scaler.fit_transform(X_sample)

# Perform linkage
linkage_matrix = linkage(X_sample_scaled, method='ward')

# Get best cut
best_cut, best_score, best_labels = find_best_cut(linkage_matrix, X_sample_scaled)

# Assign cluster numbers
df_sample['hierarchical_cluster'] = best_labels

# Optional: map numeric cluster labels to alphabetic (Cluster A, B, ...)
unique_clusters = sorted(df_sample['hierarchical_cluster'].unique())
cluster_map = {k: f"Cluster {chr(65+i)}" for i, k in enumerate(unique_clusters)}
df_sample['cluster_label'] = df_sample['hierarchical_cluster'].map(cluster_map)

# Dendrogram
plt.figure(figsize=(16, 8))
dendro = dendrogram(
    linkage_matrix,
    labels=df_sample['institution_name'].values,
    leaf_rotation=90,
    leaf_font_size=10,
    color_threshold=None,
    above_threshold_color='black'
)
plt.axhline(y=best_cut, c='red', lw=2, linestyle='--', label=f'Cut at height = {best_cut}')
plt.title("Hierarchical Clustering Dendrogram (Best Cut Height)")
plt.xlabel("University Name")
plt.ylabel("Distance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# PCA Plot
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_sample_scaled)

plt.figure(figsize=(10, 6))
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1],
                      c=df_sample['hierarchical_cluster'], cmap='Set1', alpha=0.7)
plt.title("Hierarchical Clustering (PCA 2D)")
plt.xlabel("PCA Component 1")
plt.ylabel("PCA Component 2")
plt.grid(True)
plt.legend(*scatter.legend_elements(), title="Cluster")
plt.tight_layout()
plt.show()

# Geo map
df_sample['size_value'] = df_sample['size'].map({'S': 10, 'M': 15, 'L': 20, 'XL': 25})
fig = px.scatter_geo(
    df_sample,
    locations="location_full",
    locationmode="country names",
    color="cluster_label",
    size="size_value",
    hover_name="institution_name",
    projection="natural earth",
    title="Hierarchical Clustering Map of Sampled Universities",
    opacity=0.7
)
fig.update_layout(legend_title_text='Cluster')
fig.show()

# Metrics
print(f"\n✅ Best Cut Height: {best_cut}")
silhouette_hier = best_score
db_score = davies_bouldin_score(X_sample_scaled, best_labels)
ch_score = calinski_harabasz_score(X_sample_scaled, best_labels)

print(f"Silhouette Score: {silhouette_hier:.4f}")
print(f"Davies-Bouldin Index: {db_score:.4f} (lower is better)")
print(f"Calinski-Harabasz Score: {ch_score:.2f} (higher is better)")

# Cluster sizes (alphabetic)
print("\nCluster Sizes (Alphabetic Labels):")
print(df_sample['cluster_label'].value_counts())

# Average 2025 Rank per alphabetic cluster
print("\nAverage 2025 Rank per Cluster (Alphabetic):")
print(df_sample.groupby('cluster_label')['2025_rank'].mean())



# Feature means per cluster (alphabetic)
print("\nFeature Means per Cluster (Alphabetic):")
print(df_sample.groupby('cluster_label')[features_for_clustering].mean())


# Show sample universities per alphabetic cluster label
for label in sorted(df_sample['cluster_label'].unique()):
    print(f"\nSample universities in {label}:")
    print(df_sample[df_sample['cluster_label'] == label][['institution_name', 'size', 'location_full']].head(5).to_string(index=False))








# KMeans metrics (from earlier in your code)
kmeans_sil = sil          # or replace with the variable you used in KMeans
kmeans_db = dbi
kmeans_ch = ch

# Final Comparison Table 
summary_df = pd.DataFrame({
    'Model': ['KMeans', 'DBSCAN', 'Hierarchical'],
    'Silhouette Score': [kmeans_sil, dbscan_sil, silhouette_hier],
    'Davies-Bouldin Index': [kmeans_db, dbscan_db, db_score],
    'Calinski-Harabasz Score': [kmeans_ch, dbscan_ch, ch_score]
})


print("\n Final Clustering Model Comparison (Evaluated using 2025 Rank):")
print(summary_df.sort_values(by='Silhouette Score', ascending=False))
    



# Create bar plots for each metric
fig, axes = plt.subplots(1, 3, figsize=(18, 5))

# Silhouette Score
axes[0].bar(summary_df['Model'], summary_df['Silhouette Score'], color='skyblue')
axes[0].set_title("Silhouette Score (↑ Better)")
axes[0].set_ylabel("Score")
axes[0].grid(True)

# Davies-Bouldin Index
axes[1].bar(summary_df['Model'], summary_df['Davies-Bouldin Index'], color='salmon')
axes[1].set_title("Davies-Bouldin Index (↓ Better)")
axes[1].set_ylabel("Index")
axes[1].grid(True)

# Calinski-Harabasz Score
axes[2].bar(summary_df['Model'], summary_df['Calinski-Harabasz Score'], color='lightgreen')
axes[2].set_title("Calinski-Harabasz Score (↑ Better)")
axes[2].set_ylabel("Score")
axes[2].grid(True)

plt.suptitle("Clustering Model Comparison (Evaluated Using 2025 Rank)", fontsize=14)
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()